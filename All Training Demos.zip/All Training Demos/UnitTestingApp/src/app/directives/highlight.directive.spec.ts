import {Component, DebugElement} from '@angular/core';
import {TestBed,ComponentFixture} from '@angular/core/testing';

import {Highlight} from './highlight.directive';
import { By } from '@angular/platform-browser';


export function newEvent(evtName:string,bubbles:boolean=false,cancelable:boolean=false){
    let evt = document.createEvent('CustomEvent');
    evt.initCustomEvent(evtName,bubbles,cancelable,null);
    return evt;
}


@Component({
    template:`    
    <h2 highlight> The Default Green </h2>
    <h2 highlight="yellow"> The Default Green </h2>
    <h2> No highlight</h2>
    <input type="text" #target [highlight]="target.value" value="aqua" />
    `
})
export class TestComponent{  }

describe('Highlight Directive',()=>{

        let fixture:ComponentFixture<TestComponent>;
        let debElements:DebugElement[];

    beforeEach(()=>{
       fixture = TestBed.configureTestingModule({
            declarations:[Highlight,TestComponent]
        }).createComponent(TestComponent);
        fixture.detectChanges();
       debElements = fixture.debugElement.queryAll(By.directive(Highlight))

    });// eof beforeEach
    it('no. of debug Elements to be 3',()=>{
        expect(debElements.length).toBe(3);
    })

    it('first h2 to have lightgreen color',()=>{
     let bgColor= debElements[0].nativeElement.style.backgroundColor;
     expect(bgColor).toBe('lightgreen');
    })

    it('change bgColor as per the input ',()=>{
       
        let inputType = debElements[2].nativeElement as HTMLInputElement;
        expect(inputType.style.backgroundColor).toBe('aqua','initial bgColor')
        inputType.value = "orange";
        inputType.dispatchEvent(newEvent('input'))
        fixture.detectChanges();
        expect(inputType.style.backgroundColor).toBe('orange','changed bgColor')
       })
})