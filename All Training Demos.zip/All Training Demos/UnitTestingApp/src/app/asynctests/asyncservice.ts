import {Injectable} from '@angular/core'

@Injectable()
export class AsyncService{
        simpleAsyncCall(){
            return new Promise((resolve,reject)=>{
                setTimeout(()=>resolve('Promise resolved !'),100)
            });
        }
}