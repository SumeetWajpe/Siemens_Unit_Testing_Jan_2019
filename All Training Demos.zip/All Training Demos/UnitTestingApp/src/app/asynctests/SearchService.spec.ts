import {SearchService} from './SearchService';
import {TestBed,async,fakeAsync, tick} from '@angular/core/testing';
import {MockBackend} from '@angular/http/testing';
import{
    Jsonp,
    JsonpModule,
    Response,
    ResponseOptions,
    BaseRequestOptions
} from '@angular/http';

describe('Testing Search Service',()=>{
    let service:SearchService;   
    let backend:MockBackend;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports:[JsonpModule],
            providers:[
                SearchService,
                MockBackend,
            BaseRequestOptions,
        {
            provide:Jsonp,
            useFactory:(backend,options) => new Jsonp(backend,options),
            deps:[MockBackend,BaseRequestOptions]
        }]        
                              });// eof configureTestingModule
            service = TestBed.get(SearchService);
            backend = TestBed.get(MockBackend);
               });// eof before each

    it('service must be defined',()=>{
            expect(service).toBeDefined();
    });

    it('search for the searchItems',fakeAsync(()=>{

        let response = {         

    "resultCount":5,
    "results": [
   {"wrapperType":"track", "kind":"song", "artistId":453243000, "collectionId":814424794, "trackId":814425987, "artistName":"Kishor", "collectionName":"Punjabi Wedding Songs", "trackName":"Bari Barsi", "collectionCensoredName":"Punjabi Wedding Songs", "trackCensoredName":"Bari Barsi", "collectionArtistId":814425975, "collectionArtistName":"Bani Kaur & Kishor", "collectionArtistViewUrl":"https://itunes.apple.com/us/artist/bani-kaur/814425975?uo=4", "artistViewUrl":"https://itunes.apple.com/us/artist/kishor/453243000?uo=4", "collectionViewUrl":"https://itunes.apple.com/us/album/bari-barsi/814424794?i=814425987&uo=4", "trackViewUrl":"https://itunes.apple.com/us/album/bari-barsi/814424794?i=814425987&uo=4", 
   "previewUrl":"https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/Music4/v4/f8/1b/76/f81b76b1-5f39-1830-6a13-9981674093e3/mzaf_40921914603468631.plus.aac.p.m4a", "artworkUrl30":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/30x30bb.jpg", "artworkUrl60":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/60x60bb.jpg", "artworkUrl100":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/100x100bb.jpg", "collectionPrice":7.92, "trackPrice":0.99, "releaseDate":"2011-10-17T07:00:00Z", "collectionExplicitness":"notExplicit", "trackExplicitness":"notExplicit", "discCount":1, "discNumber":1, "trackCount":8, "trackNumber":2, "trackTimeMillis":254981, "country":"USA", "currency":"USD", "primaryGenreName":"Regional Indian", "isStreamable":true}, 
   {"wrapperType":"track", "kind":"song", "artistId":453243000, "collectionId":814424794, "trackId":814425990, "artistName":"Kishor", "collectionName":"Punjabi Wedding Songs", "trackName":"Kaka Jam Paya", "collectionCensoredName":"Punjabi Wedding Songs", "trackCensoredName":"Kaka Jam Paya", "collectionArtistId":814425975, "collectionArtistName":"Bani Kaur & Kishor", "collectionArtistViewUrl":"https://itunes.apple.com/us/artist/bani-kaur/814425975?uo=4", "artistViewUrl":"https://itunes.apple.com/us/artist/kishor/453243000?uo=4", "collectionViewUrl":"https://itunes.apple.com/us/album/kaka-jam-paya/814424794?i=814425990&uo=4", "trackViewUrl":"https://itunes.apple.com/us/album/kaka-jam-paya/814424794?i=814425990&uo=4", 
   "previewUrl":"https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/Music/v4/29/a6/f2/29a6f2c0-7bc2-11bc-a721-114ed49e3e59/mzaf_7602865649866749203.plus.aac.p.m4a", "artworkUrl30":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/30x30bb.jpg", "artworkUrl60":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/60x60bb.jpg", "artworkUrl100":"https://is1-ssl.mzstatic.com/image/thumb/Music/v4/e3/61/a0/e361a0ff-face-15b9-c82a-dd0cda2163e9/source/100x100bb.jpg", "collectionPrice":7.92, "trackPrice":0.99, "releaseDate":"2011-10-17T07:00:00Z", "collectionExplicitness":"notExplicit", "trackExplicitness":"notExplicit", "discCount":1, "discNumber":1, "trackCount":8, "trackNumber":3, "trackTimeMillis":175099, "country":"USA", "currency":"USD", "primaryGenreName":"Regional Indian", "isStreamable":true}, 
   {"wrapperType":"track", "kind":"song", "artistId":453243000, "collectionId":1221857737, "trackId":1221858343, "artistName":"Kishor, Bhankar, Nischal, Sarada, Nirmala, Deepa & Yogita", "collectionName":"Naya Sankalpa", "trackName":"Aafnai Mutu", "collectionCensoredName":"Naya Sankalpa", "trackCensoredName":"Aafnai Mutu", "collectionArtistId":36270, "collectionArtistName":"Various Artists", "artistViewUrl":"https://itunes.apple.com/us/artist/kishor/453243000?uo=4", "collectionViewUrl":"https://itunes.apple.com/us/album/aafnai-mutu/1221857737?i=1221858343&uo=4", "trackViewUrl":"https://itunes.apple.com/us/album/aafnai-mutu/1221857737?i=1221858343&uo=4", 
   "previewUrl":"https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/AudioPreview122/v4/0d/8e/4c/0d8e4ca1-67ac-d04e-0a7c-01afab47db6e/mzaf_9179277383170547380.plus.aac.p.m4a", "artworkUrl30":"https://is4-ssl.mzstatic.com/image/thumb/Music111/v4/b1/c1/4d/b1c14d15-bc75-770c-2ee9-37ccc9614210/source/30x30bb.jpg", "artworkUrl60":"https://is4-ssl.mzstatic.com/image/thumb/Music111/v4/b1/c1/4d/b1c14d15-bc75-770c-2ee9-37ccc9614210/source/60x60bb.jpg", "artworkUrl100":"https://is4-ssl.mzstatic.com/image/thumb/Music111/v4/b1/c1/4d/b1c14d15-bc75-770c-2ee9-37ccc9614210/source/100x100bb.jpg", "collectionPrice":9.90, "trackPrice":0.99, "releaseDate":"2009-03-15T07:00:00Z", "collectionExplicitness":"notExplicit", "trackExplicitness":"notExplicit", "discCount":1, "discNumber":1, "trackCount":10, "trackNumber":5, "trackTimeMillis":315653, "country":"USA", "currency":"USD", "primaryGenreName":"World", "isStreamable":true}, 
   {"wrapperType":"track", "kind":"song", "artistId":453243000, "collectionId":766529570, "trackId":766529589, "artistName":"Kishor", "collectionName":"Krishnapeeyoosham", "trackName":"Pahimurare", "collectionCensoredName":"Krishnapeeyoosham", "trackCensoredName":"Pahimurare", "collectionArtistName":"Kishor, Krishna Prasad & Ayana Venugopal", "artistViewUrl":"https://itunes.apple.com/us/artist/kishor/453243000?uo=4", "collectionViewUrl":"https://itunes.apple.com/us/album/pahimurare/766529570?i=766529589&uo=4", "trackViewUrl":"https://itunes.apple.com/us/album/pahimurare/766529570?i=766529589&uo=4", 
   "previewUrl":"https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/AudioPreview71/v4/e3/c1/b7/e3c1b7ac-af88-bda1-693d-e1ff231a1852/mzaf_3325871613377117255.plus.aac.p.m4a", "artworkUrl30":"https://is5-ssl.mzstatic.com/image/thumb/Music4/v4/8f/97/cf/8f97cf03-74a9-7b1c-791e-1f4ab5fee4ee/source/30x30bb.jpg", "artworkUrl60":"https://is5-ssl.mzstatic.com/image/thumb/Music4/v4/8f/97/cf/8f97cf03-74a9-7b1c-791e-1f4ab5fee4ee/source/60x60bb.jpg", "artworkUrl100":"https://is5-ssl.mzstatic.com/image/thumb/Music4/v4/8f/97/cf/8f97cf03-74a9-7b1c-791e-1f4ab5fee4ee/source/100x100bb.jpg", "collectionPrice":6.93, "trackPrice":0.99, "releaseDate":"2008-01-02T08:00:00Z", "collectionExplicitness":"notExplicit", "trackExplicitness":"notExplicit", "discCount":1, "discNumber":1, "trackCount":7, "trackNumber":7, "trackTimeMillis":295706, "country":"USA", "currency":"USD", "primaryGenreName":"Devotional & Spiritual", "isStreamable":true}, 
   {"wrapperType":"track", "kind":"song", "artistId":1161493042, "collectionId":1165111191, "trackId":1165111340, "artistName":"Kishor", "collectionName":"Prema Lekalu - EP", "trackName":"Gharshana", "collectionCensoredName":"Prema Lekalu - EP", "trackCensoredName":"Gharshana", "collectionArtistId":1165111205, "collectionArtistName":"Suresh Vishwa", "collectionArtistViewUrl":"https://itunes.apple.com/us/artist/suresh-vishwa/1165111205?uo=4", "artistViewUrl":"https://itunes.apple.com/us/artist/kishor/1161493042?uo=4", "collectionViewUrl":"https://itunes.apple.com/us/album/gharshana/1165111191?i=1165111340&uo=4", "trackViewUrl":"https://itunes.apple.com/us/album/gharshana/1165111191?i=1165111340&uo=4", 
   "previewUrl":"https://audio-ssl.itunes.apple.com/apple-assets-us-std-000001/AudioPreview71/v4/df/d3/19/dfd319e4-9ba4-ed38-e961-2c95a1d05a88/mzaf_8079020761921874874.plus.aac.p.m4a", "artworkUrl30":"https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/d2/10/16/d2101616-6e90-4885-add4-d992e656b27c/source/30x30bb.jpg", "artworkUrl60":"https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/d2/10/16/d2101616-6e90-4885-add4-d992e656b27c/source/60x60bb.jpg", "artworkUrl100":"https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/d2/10/16/d2101616-6e90-4885-add4-d992e656b27c/source/100x100bb.jpg", "collectionPrice":5.99, "trackPrice":1.29, "releaseDate":"2013-01-15T08:00:00Z", "collectionExplicitness":"notExplicit", "trackExplicitness":"notExplicit", "discCount":1, "discNumber":1, "trackCount":6, "trackNumber":4, "trackTimeMillis":297013, "country":"USA", "currency":"USD", "primaryGenreName":"Indian Pop", "isStreamable":true}]
   }  
        backend.connections.subscribe(connection =>{
            connection.mockRespond(
                new Response(<ResponseOptions>{
                    body: JSON.stringify(response)
                })
            )
        });
// expect //??
service.search("Kishor");

tick();
expect(service.results.length).toBe(5);
expect(service.results[0].artist).toBe("Kishor");

    }));   
});

