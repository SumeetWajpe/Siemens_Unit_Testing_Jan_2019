import {GreetingService} from './Greeting.service';
import {TestBed,async,fakeAsync, tick, inject} from '@angular/core/testing';
describe('Service Instance Creation (Manual)',()=>{
    var servObj:GreetingService;
    beforeEach(()=>{
            servObj = new GreetingService(); // Manual (No Need of Testing Module !)
    })
});

describe('Service Instance Creation (Using TestBed)',()=>{
    var servObj:GreetingService;
    beforeEach(()=>{
           TestBed.configureTestingModule({
               providers:[GreetingService]
           });           
    });

    it('should be creating service instance (get)',()=>{
        servObj = TestBed.get(GreetingService);
        expect(servObj).toBeDefined();
    });   
});

describe('Service Instance Creation (Testcase Level Injection) (Using TestBed)',()=>{
    var servObj:GreetingService;
    beforeEach(()=>{
           TestBed.configureTestingModule({
               providers:[GreetingService]
           });           
    });
    it('should be creating service instance (inject)', inject([GreetingService],(service:GreetingService)=>{
        expect(service).toBeDefined();
        expect(service.greet('Sumeet')).toBe('Hello Sumeet');

    }) );   
});


describe('Create Testing Module',()=>{
    beforeEach(()=>{
        TestBed.configureTestingModule({
            providers:[GreetingService]        
                            });
                            });// eof beforeEach

describe('Service Instance Creation (Testsuite Level Injection) (Using TestBed)',()=>{
    var servObj:GreetingService;
    beforeEach(inject([GreetingService],(service:GreetingService)=>{
            servObj = service;
        }));
   afterEach(()=>{
       servObj =null;
   });

   it('to Be Defined !',()=>{
       expect(servObj).toBeDefined();
   });
});
});


