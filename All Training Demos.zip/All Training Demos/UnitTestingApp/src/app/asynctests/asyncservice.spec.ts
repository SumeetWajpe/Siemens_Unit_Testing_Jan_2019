import {AsyncService} from './asyncservice';
import {TestBed,async,fakeAsync, tick} from '@angular/core/testing';

describe('AsyncService',()=>{

    let servObj:AsyncService;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            providers:[AsyncService]
        });
        // servObj = new AsyncService(); // Manually creating the service instance !
        servObj = TestBed.get(AsyncService);
    });// eof before Each

    it('should create a service instance',()=>{
        expect(servObj).toBeDefined();
    });

    it('should handle a simple async Scenario',async(()=>{
        servObj.simpleAsyncCall().then(result =>{
            expect(result).toBe('Promise resolved !');
        })
    }))

    it('should work for local variable value',fakeAsync(()=>{
        let value;
        servObj.simpleAsyncCall().then(result =>{
            value = result;
        });
        expect(value).not.toBeDefined();
        tick(50);
        expect(value).not.toBeDefined();
        tick(50);
        expect(value).toBeDefined();        

    }));

})