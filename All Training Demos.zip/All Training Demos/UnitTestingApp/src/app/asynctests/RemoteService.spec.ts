import {RemoteService} from './RemoteService';
import {TestBed,async,fakeAsync, tick} from '@angular/core/testing';
import {
    HttpClientTestingModule,
    HttpTestingController} from '@angular/common/http/testing';

describe('Testing Remote Service',()=>{

    let service:RemoteService;
    let httpMock:HttpTestingController;

    beforeEach(()=>{
        TestBed.configureTestingModule({
            imports:[HttpClientTestingModule],
            providers:[RemoteService]        
                              });// eof configureTestingModule
            service = TestBed.get(RemoteService);
            httpMock = TestBed.get(HttpTestingController);

                });// eof before each

    it('service must be defined',()=>{
            expect(service).toBeDefined();
    });

    it('should return json',()=>{
        service.fetchViaHttp().subscribe(
            response => expect(response.name).toBe('Siemens')
        );

        let req = httpMock.expectOne('https://jsonplaceholder.typicode.com/posts','call to the API');
        expect(req.request.method).toBe('GET');

        req.flush({
            name:'Siemens'
        });
    });   
});