import {TestBed,async,fakeAsync, tick} from '@angular/core/testing';
import {FilterPipe} from './filterpipe';

describe('Filter Pipe',()=>{
   let filterPipe:FilterPipe;

   beforeEach(()=>{
       filterPipe = new FilterPipe();
   })
   
    it('should return an empty array if no items',()=>{
        const items = null;
        var filteredItems =filterPipe.transform(items,'name','Sumeet');
        expect(filteredItems.length).toBe(0);
        expect(filteredItems).toEqual([]);

    });
    
    it('should return items if no field',()=>{
        const items = [];
        items.push({id:1,name:'Sumeet'});
        var filteredItems =filterPipe.transform(items,null,'Sumeet');
        expect(filteredItems.length).toBe(1);
        expect(filteredItems).toEqual(items);
    });
    
    it('should filter correctly',()=>{
        const items = [];
        items.push({id:1,name:'Sumeet'});
        items.push({id:2,name:'Ameet'});
        items.push({id:3,name:'Puneet'});
        items.push({id:4,name:'Amit'});
        items.push({id:5,name:'Sumit'});
        var filteredItems =filterPipe.transform(items,'name','Sumeet');
        expect(filteredItems.length).toBe(1);      
    })

})