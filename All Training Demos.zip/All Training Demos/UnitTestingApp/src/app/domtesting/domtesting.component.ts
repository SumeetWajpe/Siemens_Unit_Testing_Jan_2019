import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-domtesting',
  template:`<div class="container" *ngIf="isVisible">
                        Toogle the div !
                    </div>
  
  <button (click)="isVisible=!isVisible">Toggle !</button>
  `,
  styleUrls: ['./domtesting.component.css']
})
export class DomtestingComponent implements OnInit {

  isVisible = false;
  constructor() { }

  ngOnInit() {
  }

}
