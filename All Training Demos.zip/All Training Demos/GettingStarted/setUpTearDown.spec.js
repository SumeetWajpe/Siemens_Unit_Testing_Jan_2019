


xdescribe('setup/teardown',function(){

    var obj = [1,2,3];
    beforeAll(function(){
        console.log('within beforeAll');
});

afterAll(function(){
    console.log('within afterAll');

});
beforeEach(function(){
    console.log('within beforeEach');

});

afterEach(function(){
    console.log('within afterEach');
});

    it('just test the value of obj',function(){
        console.log('Within It')
        expect(obj).toContain(2);
    })
});

xdescribe("A suite", function() {
    it("contains spec with an expectation", function() {
      expect(true).toBe(true);
    });
    beforeAll(function(){
        console.log('within another beforeAll');
});

afterAll(function(){
    console.log('within another afterAll');

});
beforeEach(function(){
    console.log('within another beforeEach');

});

afterEach(function(){
    console.log('within another afterEach');
});
  });