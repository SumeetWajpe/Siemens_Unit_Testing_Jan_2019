describe('Basic Spying',function(){

    beforeEach(function(){
        this.increment = function(x,y){
            console.log(y);
            return x + 1;
        }

        spyOn(this,'increment')
    });

    xit('spyon the function',function(){
       var nextValue = this.increment(20); //calling !
        expect(this.increment).toHaveBeenCalled()
        expect(nextValue).toBeDefined();
    })

    xit('spyon the function with returned value',function(){
        this.increment.and.callThrough();
        var nextValue = this.increment(20); //calling !
         expect(this.increment).toHaveBeenCalledWith(20)
         expect(nextValue).toBeDefined();
     });

     xit('spyon the function with parameters',function(){
        this.increment.and.callThrough();
        var nextValue = this.increment(20); //calling !
         //expect(this.increment).toHaveBeenCalledWith(20)
         expect(this.increment).toHaveBeenCalledWith(jasmine.any(Number))
     });

     xit('spyon the function with parameters',function(){
        this.increment.and.returnValue(100);
        var nextValue = this.increment(20); //calling !       
         expect(nextValue).toBe(100);
     });

     xit('spyon the function with a fakeCall',function(){
        this.increment.and.callFake(function(val){
            return val * 2;
        })
        var nextValue = this.increment(20); //calling !       
         expect(nextValue).toBe(40);
     });


     xit('spyon the function with number of invocations',function(){
        this.increment(20); //calling !       
        this.increment(20); //calling !       
        this.increment(20); //calling !       
        this.increment(20); //calling !       

         expect(this.increment.calls.count()).toBe(4);
     });


     it('spyon the function with argument',function(){
        this.increment(20,40); //calling !     

        expect(this.increment.calls.argsFor(0)[1]).toEqual(40);
         //expect(this.increment.calls.argsFor(1)).toEqual([40]);
     });

    

     



});