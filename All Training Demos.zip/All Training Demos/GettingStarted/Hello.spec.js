xdescribe("A suite", function() {
    it("contains spec with an expectation", function() {
      expect(true).toBe(true);
    });
  });

  function Add(x,y){
      return x + y;
  }
  function Addition(x,y){
    return x + y;
}

 xdescribe("An addition suite", function() {
    it("add two numbers", function() {
      expect(Add(20,30)).toEqual(60,'The Addition Failed !!!');
    });
  });

  
  xdescribe("BasicMatchers", function() {
    xit("toBe: ===", function() {
      expect('60').toBe(60);
    });

    xit("toEqual: === + object inspection", function() {
       // expect('60').toBe(60);
       //expect([1,2,3]).toEqual([1,2,3]);
       //expect({name:'Sumeet'}).not.toEqual({name:'Sumit'});
      //expect(Add).toEqual(Addition)
    });

    xit("toMatch - regEx",function(){
            expect('Happy Diwali').toMatch(/happy /i)
    });

    xit("toBeDefined",function(){
        var b={};
        expect(b.property).toBeUndefined();
    });

    xit("toContain",function(){
        var person = {name:'Sumeet',city:'Pune'}
        //expect([1,2,3,4,5]).toContain(2);
        expect('Sumeet is the name').toContain('name')
    });


  });

  xdescribe('Using Custom Matchers',function(){
      it('toBeType',function(){
          expect(5).not.toBeOfType('string','Type is Wrong !')
      })
  })