var customMatchers ={
    toBeOfType:function(util,customEqualityTesters){
            return{
                compare:function(actual,expected,message){
                  var ret = {};
                    if(expected == 'number'){
                        ret.pass = util.equals(typeof actual,expected,customEqualityTesters)
                        if(ret.pass){
                            ret.message = "Expected " + typeof actual + " to be" + expected + " " + message;
                         }
                         else{
                            ret.message = "Expected " + typeof actual + " to not be" + expected + " " + message;
                        
                        }                                          
                    }
                    return ret;                
                }
            }
    }
}

beforeEach(function(){
    jasmine.addMatchers(customMatchers);
});