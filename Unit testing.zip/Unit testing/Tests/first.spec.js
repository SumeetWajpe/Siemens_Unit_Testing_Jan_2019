xdescribe("First test suite",function(){
    it("first test case",function(){
        expect(true).tobe(false);
    });
    });

    xdescribe("BasicMatchers",function(){
        xit("tobe is ==",function(){
            expect('10').tobe(10);
        });
        xit("toEqual === + Object Inspection",function(){
            //expect([10,20,30]).toEqual([10,20,30]);
            //expect({name:'Sowmya'}).toEqual({name:'soumya'});
        });
        xit("toMatch",function(){
            expect("Happy New Year").toMatch(/happy /i);
        });
        xit("toBeDefiend",function(){
            var obj={ };
            expect(obj.someprop).not.toBeDefined();
        });
        });
        xdescribe('Using custom Matcher',function(){
            xit('toBeType',function(){
               // console.log('Running test...');
                expect(10).not.toBeOfType('string','Type MisNatch !')
            });
        });