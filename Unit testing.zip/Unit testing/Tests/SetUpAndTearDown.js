xdescribe("setUp/TearDown",function(){

    var obj;
    beforeEach(function(){
        obj=[10,20,30];
        console.log('Within Before each');
    });
    beforeAll(function(){
        console.log('Within Before All');
    });
    afterEach(function(){
        console.log('Within After each');
    });
    afterAll(function(){
        console.log('Within after All');
    });
    xit("toMatch",function(){
        console.log('Running test..');
        expect("Happy New Year").toMatch(/happy /i);
    });
    xit("toMatch2",function(){
        console.log('Running test..');
        expect(obj).toContain(20);
    });
});