describe("spying",function(){

    beforeEach(function(){
        this.increment= function(x,y){
            console.log('Increment....');
            return x+1;
        }
        spyOn(this,'increment')
        });
    xit("spy on the function",function(){
        var thenextValue= this.increment(20);
        //expect(this.increment).toHaveBeenCalled();
         expect(thenextValue).toBeDefined();
    });

   xit("spy on the  with returned value",function(){
       
        this.increment.and.callThrough();
       var thenextValue=this.increment(20);
       // expect(this.increment).toHaveBeenCalledWith(20);
        expect(thenextValue).toBeDefined();
         
    });


    it("spy on the  with callfake",function(){
       
        this.increment.and.callFake(function(val){
return val*2;
        });
       var thenextValue=this.increment(20);
        expect(thenextValue).toBe(40);
        //expect(thenextValue).toBeDefined();
         
    });
});
