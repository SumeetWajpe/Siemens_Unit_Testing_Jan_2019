var customMatchers = {
    toBeOfType: function (util, customEqualityTesters) {
        return {
            compare: function (actual, expected, message) {
                var retval = { };
                if (expected == 'number') {
                    retval.pass = util.equals(typeof actual, expected, customEqualityTesters);
                    if (retval.pass) {
                        retval.message = "Expected" + typeof actual + "to be" + expected + " " + message;
                    }
                    else {
                        retval.message = "Expected" + typeof actual + "not to be" + expected + " " + message;
                    }

                }
                return retval;
            }
        }
    }
}

beforeEach(function ()
{
    jasmine.addMatchers(customMatchers)
})